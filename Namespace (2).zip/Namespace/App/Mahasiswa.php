<?php
namespace App;
Class Mahasiswa {
    function __construct(){
         echo "Saya app/Mahasiswa.php";
    }
}