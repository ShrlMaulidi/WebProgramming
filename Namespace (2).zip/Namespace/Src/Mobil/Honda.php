<?php
namespace Dummy\Mobil;
Class Honda extends Mobil{
protected $efisiensi = 15;
 public function getEfisiensi() {
    return $this->efisiensi;
 }
}