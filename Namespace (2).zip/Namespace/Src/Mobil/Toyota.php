<?php
namespace Dummy\Mobil;
Class Toyota extends Mobil{
protected $efisiensi = 5;
 public function getEfisiensi() {
    return $this->efisiensi;
 }
}